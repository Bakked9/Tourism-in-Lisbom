from django.contrib import admin
from .models import Attraction

# Registering the model.

admin.site.register(Attraction)

